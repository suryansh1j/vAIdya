"use client"

import type React from "react"

import Link from "next/link"
import { useState, useRef } from "react"

export default function Home() {
  const [isRecording, setIsRecording] = useState(false)
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null)
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const audioChunksRef = useRef<Blob[]>([])

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      mediaRecorderRef.current = new MediaRecorder(stream)
      audioChunksRef.current = []

      mediaRecorderRef.current.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data)
      }

      mediaRecorderRef.current.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: "audio/webm" })
        setAudioBlob(audioBlob)
      }

      mediaRecorderRef.current.start()
      setIsRecording(true)
    } catch (error) {
      console.error("[v0] Error accessing microphone:", error)
      alert("Could not access microphone. Please ensure it's enabled.")
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop()
      setIsRecording(false)
    }
  }

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0]
    if (file) {
      setAudioBlob(file)
    }
  }

  const handleSubmit = () => {
    if (audioBlob) {
      console.log("[v0] Submitting audio:", audioBlob)
      // In a real application, you would upload this audioBlob to a server
      alert("Audio submitted! (Check console for blob data)")
      setAudioBlob(null) // Clear after submission
    } else {
      alert("Please record or upload audio first.")
    }
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 w-full border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="text-2xl font-bold text-primary">
            vAIdya
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/ml-predictor" className="text-sm font-medium transition-colors hover:text-primary">
              ML Predictor
            </Link>
            <Link href="/doctors-notes" className="text-sm font-medium transition-colors hover:text-primary">
              Doctor&apos;s Notes
            </Link>
            <Link href="/our-progress" className="text-sm font-medium transition-colors hover:text-primary">
              Our Progress and Goals
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] p-4 md:p-8">
        <h1 className="text-4xl md:text-6xl font-bold text-center text-balance mb-6">
          Revolutionizing Healthcare with AI
        </h1>
        <p className="text-lg md:text-xl text-center text-muted-foreground max-w-2xl mb-10">
          Empowering medical professionals with intelligent tools for diagnosis and patient management.
        </p>
        <div className="flex flex-col items-center space-y-4">
          <div className="flex space-x-4">
            {isRecording ? (
              <button
                onClick={stopRecording}
                className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-destructive text-destructive-foreground hover:bg-destructive/90 h-10 px-4 py-2"
              >
                Stop Recording
              </button>
            ) : (
              <button
                onClick={startRecording}
                className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
              >
                Record Audio
              </button>
            )}
            <label
              htmlFor="audio-upload"
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 border border-input bg-background hover:bg-accent hover:text-accent-foreground h-10 px-4 py-2 cursor-pointer"
            >
              Upload Audio
              <input id="audio-upload" type="file" accept="audio/*" onChange={handleFileUpload} className="sr-only" />
            </label>
          </div>
          {audioBlob && (
            <p className="text-sm text-muted-foreground">Audio ready: {audioBlob.name || "Recorded Audio"}</p>
          )}
          <button
            onClick={handleSubmit}
            disabled={!audioBlob}
            className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2 w-48"
          >
            Submit
          </button>
        </div>
      </main>
    </div>
  )
}
