"use client"

import type React from "react"

import Link from "next/link"
import { useState } from "react"
import jsPDF from "jspdf"
// import html2canvas from "html2canvas"

export default function DoctorsNotesPage() {
  const [formData, setFormData] = useState({
    patientName: "John Doe",
    age: "35",
    sex: "male",
    address: "123 Main St, Anytown, USA",
    medicalHistory:
      "Patient has a history of seasonal allergies, well-controlled with over-the-counter antihistamines. No history of chronic diseases such as diabetes, hypertension, or heart conditions. Last physical examination was 6 months ago, with all labs within normal limits. No known drug allergies. Childhood immunizations are up to date. No history of surgeries or hospitalizations. The patient also reported a previous fracture of the left arm at age 10, which healed without complications. Regular dental check-ups are maintained, and no significant oral health issues have been noted. Annual flu vaccinations are received. No history of mental health disorders. Patient is a non-smoker and consumes alcohol occasionally, in moderation.",
    familyHistory:
      "Father had hypertension diagnosed at age 50, currently managed with medication. Mother has no known significant medical issues. Paternal grandfather had type 2 diabetes. No family history of genetic disorders or autoimmune diseases. Patient has one sibling, a sister, who is healthy. Maternal grandmother had osteoporosis. No history of early-onset heart disease or cancer in immediate family. Both parents are alive and in good health, aside from father's hypertension. No known hereditary conditions.",
    currentSymptoms:
      "Patient presents with a persistent mild cough for the past 3 days, accompanied by general fatigue and occasional headaches. The cough is non-productive and tends to worsen in the evenings. No fever, chills, sore throat, or difficulty breathing reported. Denies any recent travel or exposure to sick individuals. Appetite is normal, but reports feeling more tired than usual. The headaches are described as dull and frontal, relieved by over-the-counter pain relievers. No associated nausea, vomiting, or photophobia. The fatigue is generalized and has been present for about a week, not relieved by rest. No recent changes in diet or sleep patterns. Patient denies any chest pain, palpitations, or dizziness.",
    vitals: "BP: 120/80 mmHg, Temp: 98.6°F (37°C), HR: 72 bpm, RR: 16 breaths/min, SpO2: 99% on room air.",
    prescriptions:
      "1. Rest and increased fluid intake. 2. Over-the-counter cough syrup (Dextromethorphan) as needed for cough. 3. Ibuprofen 200mg every 6 hours for headache, as needed. 4. Advised to avoid strenuous activities for the next 48 hours. 5. Recommend gargling with warm salt water for throat comfort. 6. Follow-up in 5-7 days or sooner if symptoms worsen. 7. Consider a humidifier for nighttime cough relief. 8. Maintain a balanced diet and ensure adequate sleep.",
    notes:
      "Patient is a 35-year-old male presenting with mild upper respiratory symptoms. Clinical examination reveals clear lung sounds bilaterally, no lymphadenopathy, and normal oropharyngeal findings. Patient appears well-hydrated and in no acute distress. Given the mild nature of symptoms and absence of red flags, a viral etiology is suspected. Patient educated on symptom management and warning signs for which to seek further medical attention. Follow-up recommended if symptoms persist beyond 7 days or worsen significantly. Encouraged to maintain good hand hygiene and avoid close contact with others to prevent spread of infection. Patient expressed understanding of the treatment plan and agreed to follow recommendations. No concerns were raised regarding medication adherence or access to care. Patient will be provided with an informational leaflet on common cold management. Discussed the importance of hydration and rest for recovery. Advised to contact the clinic if any new or concerning symptoms develop.",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("[v0] Doctor's Notes Submitted:", formData)
    alert("Doctor's Notes submitted! (Check console for form data)")
    // In a real application, you would send this data to a backend API
  }

  const downloadPdf = () => {
    const pdf = new jsPDF("p", "mm", "a4")
    const pageWidth = pdf.internal.pageSize.getWidth()
    const pageHeight = pdf.internal.pageSize.getHeight()
    const leftMargin = 20
    const rightMargin = 20
    const topMargin = 20
    const bottomMargin = 20
    const contentWidth = pageWidth - leftMargin - rightMargin
    let yPos = topMargin
    const lineHeight = 6 // Base line height for normal text

    const checkPageBreak = (requiredHeight: number) => {
      if (yPos + requiredHeight > pageHeight - bottomMargin) {
        pdf.addPage()
        yPos = topMargin // Reset yPos for new page
      }
    }

    // Title
    pdf.setFont("helvetica", "bold")
    pdf.setFontSize(22)
    checkPageBreak(10) // Check before adding title
    pdf.text("Doctor's Notes - vAIdya", pageWidth / 2, yPos, { align: "center" })
    yPos += 10

    // Date and Time
    pdf.setFont("helvetica", "normal")
    pdf.setFontSize(10)
    const now = new Date()
    checkPageBreak(5) // Check before adding date/time
    pdf.text(`Date: ${now.toLocaleDateString()} Time: ${now.toLocaleTimeString()}`, pageWidth / 2, yPos, {
      align: "center",
    })
    yPos += 15

    // Horizontal Line after header
    pdf.setDrawColor(180, 180, 180) // Light grey
    checkPageBreak(5) // Check before adding line
    pdf.line(leftMargin, yPos, pageWidth - rightMargin, yPos)
    yPos += 10

    const addSection = (title: string, data: Record<string, string>) => {
      checkPageBreak(15) // Check for section title and initial spacing
      pdf.setFont("helvetica", "bold")
      pdf.setFontSize(16) // Slightly larger font for section titles
      pdf.text(title, leftMargin, yPos)
      yPos += 10 // Increased spacing after section title

      pdf.setFont("helvetica", "normal")
      pdf.setFontSize(12) // Standard font size for content

      Object.entries(data).forEach(([key, value]) => {
        const label = key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())
        const labelText = `${label}:`

        checkPageBreak(lineHeight * 2) // Check for label and at least one line of value

        pdf.setFont("helvetica", "bold")
        pdf.text(labelText, leftMargin, yPos)
        pdf.setFont("helvetica", "normal")

        const valueText = value || "N/A"
        const availableValueWidth = contentWidth - pdf.getTextWidth(labelText) - 5
        const splitValue = pdf.splitTextToSize(valueText, availableValueWidth > 0 ? availableValueWidth : contentWidth)

        const textHeight = splitValue.length * lineHeight

        checkPageBreak(textHeight + lineHeight) // Check for text height + some padding

        if (
          splitValue.length === 1 &&
          pdf.getTextWidth(labelText) + pdf.getTextWidth(splitValue[0]) + 5 < contentWidth
        ) {
          pdf.text(splitValue, leftMargin + pdf.getTextWidth(labelText) + 5, yPos)
          yPos += lineHeight // Advance yPos by one line height
        } else {
          // If the label and first line of value don't fit on one line, or if it's multi-line
          pdf.text(splitValue, leftMargin + 5, yPos + lineHeight) // Indent wrapped text below label
          yPos += textHeight + lineHeight // Advance yPos by text height + extra line for spacing
        }
        yPos += 3 // Small extra space after each field
      })
      yPos += 5 // Extra space after each section
    }

    // Patient Details
    addSection("Patient Details", {
      patientName: formData.patientName,
      age: formData.age,
      sex: formData.sex,
      address: formData.address,
    })
    checkPageBreak(5)
    pdf.line(leftMargin, yPos, pageWidth - rightMargin, yPos)
    yPos += 10

    // Medical History
    addSection("Medical History", {
      medicalHistory: formData.medicalHistory,
      familyHistory: formData.familyHistory,
    })
    checkPageBreak(5)
    pdf.line(leftMargin, yPos, pageWidth - rightMargin, yPos)
    yPos += 10

    // Current Condition
    addSection("Current Condition", {
      currentSymptoms: formData.currentSymptoms,
      vitals: formData.vitals,
    })
    checkPageBreak(5)
    pdf.line(leftMargin, yPos, pageWidth - rightMargin, yPos)
    yPos += 10

    // Treatment and Notes
    addSection("Treatment and Notes", {
      prescriptions: formData.prescriptions,
      notes: formData.notes,
    })
    checkPageBreak(5)
    pdf.line(leftMargin, yPos, pageWidth - rightMargin, yPos)
    yPos += 10

    pdf.save("doctors-notes.pdf")
  }

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 w-full border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="text-2xl font-bold text-primary">
            vAIdya
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/ml-predictor" className="text-sm font-medium transition-colors hover:text-primary">
              ML Predictor
            </Link>
            <Link href="/doctors-notes" className="text-sm font-medium transition-colors hover:text-primary">
              Doctor&apos;s Notes
            </Link>
            <Link href="/our-progress" className="text-sm font-medium transition-colors hover:text-primary">
              Our Progress and Goals
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] p-4 md:p-8">
        <h1 className="text-4xl md:text-5xl font-bold text-center text-balance mb-8">Doctor&apos;s Notes</h1>

        <form
          id="doctors-notes-form"
          onSubmit={handleSubmit}
          className="w-full max-w-4xl bg-card p-6 rounded-lg shadow-lg space-y-6"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="patientName" className="block text-sm font-medium text-muted-foreground mb-1">
                Patient Name
              </label>
              <input
                type="text"
                id="patientName"
                name="patientName"
                value={formData.patientName}
                onChange={handleChange}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                required
              />
            </div>
            <div>
              <label htmlFor="age" className="block text-sm font-medium text-muted-foreground mb-1">
                Age
              </label>
              <input
                type="number"
                id="age"
                name="age"
                value={formData.age}
                onChange={handleChange}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                required
              />
            </div>
            <div>
              <label htmlFor="sex" className="block text-sm font-medium text-muted-foreground mb-1">
                Sex
              </label>
              <select
                id="sex"
                name="sex"
                value={formData.sex}
                onChange={handleChange}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                required
              >
                <option value="">Select</option>
                <option value="male">Male</option>
                <option value="female">Female</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label htmlFor="address" className="block text-sm font-medium text-muted-foreground mb-1">
                Address
              </label>
              <input
                type="text"
                id="address"
                name="address"
                value={formData.address}
                onChange={handleChange}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                required
              />
            </div>
          </div>

          <div>
            <label htmlFor="medicalHistory" className="block text-sm font-medium text-muted-foreground mb-1">
              Medical History
            </label>
            <textarea
              id="medicalHistory"
              name="medicalHistory"
              value={formData.medicalHistory}
              onChange={handleChange}
              rows={4}
              className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
            ></textarea>
          </div>

          <div>
            <label htmlFor="familyHistory" className="block text-sm font-medium text-muted-foreground mb-1">
              Family History
            </label>
            <textarea
              id="familyHistory"
              name="familyHistory"
              value={formData.familyHistory}
              onChange={handleChange}
              rows={4}
              className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
            ></textarea>
          </div>

          <div>
            <label htmlFor="currentSymptoms" className="block text-sm font-medium text-muted-foreground mb-1">
              Current Symptoms
            </label>
            <textarea
              id="currentSymptoms"
              name="currentSymptoms"
              value={formData.currentSymptoms}
              onChange={handleChange}
              rows={4}
              className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              required
            ></textarea>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="vitals" className="block text-sm font-medium text-muted-foreground mb-1">
                Vitals (e.g., BP, Temp, HR)
              </label>
              <input
                type="text"
                id="vitals"
                name="vitals"
                value={formData.vitals}
                onChange={handleChange}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              />
            </div>
            <div>
              <label htmlFor="prescriptions" className="block text-sm font-medium text-muted-foreground mb-1">
                Prescriptions
              </label>
              <input
                type="text"
                id="prescriptions"
                name="prescriptions"
                value={formData.prescriptions}
                onChange={handleChange}
                className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
              />
            </div>
          </div>

          <div>
            <label htmlFor="notes" className="block text-sm font-medium text-muted-foreground mb-1">
              Additional Notes
            </label>
            <textarea
              id="notes"
              name="notes"
              value={formData.notes}
              onChange={handleChange}
              rows={4}
              className="flex w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
            ></textarea>
          </div>

          <div className="flex justify-between items-center border-t border-border pt-6">
            <Link
              href="/"
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-secondary text-secondary-foreground hover:bg-secondary/80 h-10 px-4 py-2"
            >
              Back to Home
            </Link>
            <button
              type="button"
              onClick={downloadPdf}
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 hover:bg-blue-700 h-10 px-4 py-2 bg-card-foreground text-secondary"
            >
              Download PDF
            </button>
            <button
              type="submit"
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-primary text-primary-foreground hover:bg-primary/90 h-10 px-4 py-2"
            >
              Submit Notes
            </button>
          </div>
        </form>
      </main>
    </div>
  )
}
