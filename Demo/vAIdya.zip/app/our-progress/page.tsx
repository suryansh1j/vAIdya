import type React from "react"
import Link from "next/link"

export default function OurProgressPage() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 w-full border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="text-2xl font-bold text-primary">
            vAIdya
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/ml-predictor" className="text-sm font-medium transition-colors hover:text-primary">
              ML Predictor
            </Link>
            <Link href="/doctors-notes" className="text-sm font-medium transition-colors hover:text-primary">
              Doctor&apos;s Notes
            </Link>
            <Link href="/our-progress" className="text-sm font-medium transition-colors hover:text-primary">
              Our Progress and Goals
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] p-4 md:p-8">
        <h1 className="text-4xl md:text-5xl font-bold text-center text-balance mb-8">Our Progress and Goals</h1>

        <div className="w-full max-w-3xl space-y-12">
          <section>
            <h2 className="text-3xl font-semibold text-primary mb-6">Current Progress</h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <ProgressBubble
                icon={<CheckIcon className="w-6 h-6 text-green-500" />}
                title="NLP Pipeline"
                description="Built a working NLP pipeline for doctor–patient audio transcripts."
                delay="0s"
              />
              <ProgressBubble
                icon={<CheckIcon className="w-6 h-6 text-green-500" />}
                title="ML Model Training"
                description="Trained and validated our ML model to detect patient details (name, age, sex, medications, symptoms, etc.)."
                delay="0.1s"
              />
              <ProgressBubble
                icon={<CheckIcon className="w-6 h-6 text-green-500" />}
                title="Web Interface Prototype"
                description="Designed a web interface prototype with audio upload → transcript → doctor notes → PDF export."
                delay="0.2s"
              />
              <ProgressBubble
                icon={<SettingsIcon className="w-6 h-6 text-muted-foreground" />}
                title="Backend Deployment"
                description="Backend pipeline ready but not yet deployed."
                delay="0.3s"
              />
            </div>
          </section>

          <hr className="border-t border-border" />

          <section>
            <h2 className="text-3xl font-semibold text-primary mb-6">Goals & Roadmap</h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
              <ProgressBubble
                icon={<GlobeIcon className="w-6 h-6 text-primary" />}
                title="Deploy at Scale"
                description="Deploy at scale for hospitals and healthcare customers."
                delay="0.4s"
              />
              <ProgressBubble
                icon={<BotIcon className="w-6 h-6 text-primary" />}
                title="Chatbot Integration"
                description="Integrate a chatbot for patients/clients to interact with reports and ask medical queries."
                delay="0.5s"
              />
              <ProgressBubble
                icon={<BookIcon className="w-6 h-6 text-primary" />}
                title="Expand Knowledge Base"
                description="Expand medical knowledge base to cover all major diseases, symptoms, and treatments."
                delay="0.6s"
              />
              <ProgressBubble
                icon={<DatabaseIcon className="w-6 h-6 text-primary" />}
                title="Historical Data Access"
                description="Provide doctors with access to historical patient data for better and faster diagnosis."
                delay="0.7s"
              />
              <ProgressBubble
                icon={<LockIcon className="w-6 h-6 text-primary" />}
                title="Security & Compliance"
                description="Ensure security, privacy, and compliance with healthcare standards (HIPAA/GDPR-ready)."
                delay="0.8s"
              />
            </div>
          </section>
        </div>

        <div className="mt-8">
          <Link
            href="/"
            className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-secondary text-secondary-foreground hover:bg-secondary/80 h-10 px-4 py-2"
          >
            Back to Home
          </Link>
        </div>
      </main>
    </div>
  )
}

interface ProgressBubbleProps {
  icon: React.ReactNode
  title: string
  description: string
  delay: string
}

function ProgressBubble({ icon, title, description, delay }: ProgressBubbleProps) {
  return (
    <div
      className="relative flex flex-col items-center justify-center p-6 bg-card rounded-lg shadow-lg text-center animate-fade-in transition-all duration-300 ease-in-out hover:scale-105 hover:shadow-xl hover:-translate-y-2"
      style={{ animationDelay: delay }}
    >
      <div className="mb-4">{icon}</div>
      <h3 className="text-xl font-semibold text-foreground mb-2">{title}</h3>
      <p className="text-muted-foreground text-sm">{description}</p>
    </div>
  )
}

function CheckIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M20 6 9 17l-5-5" />
    </svg>
  )
}

function SettingsIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.73.73a2 2 0 0 0 .73 2.73l.09.15a2 2 0 0 1 0 2l-.08.15a2 2 0 0 0-.73 2.73l.73.73a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.73-.73a2 2 0 0 0-.73-2.73l-.09-.15a2 2 0 0 1 0-2l-.08-.15a2 2 0 0 0-.73-2.73l-.73-.73a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
      <circle cx="12" cy="12" r="3" />
    </svg>
  )
}

function GlobeIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M2 14h20" />
    </svg>
  )
}

function BotIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M12 8V4H8" />
      <rect width="16" height="12" x="4" y="8" rx="2" />
      <path d="M2 14h2" />
      <path d="M20 14h2" />
      <path d="M7 12v2h10v-2" />
      <path d="M12 17v4" />
      <path d="M8 21h8" />
    </svg>
  )
}

function BookIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20" />
    </svg>
  )
}

function DatabaseIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <ellipse cx="12" cy="5" rx="9" ry="3" />
      <path d="M3 5V19A9 3 0 0 0 21 19V5" />
      <path d="M3 12A9 3 0 0 0 21 12" />
    </svg>
  )
}

function LockIcon(props: React.SVGProps<SVGSVGElement>) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <rect width="18" height="11" x="3" y="11" rx="2" ry="2" />
      <path d="M7 11V7a5 5 0 0 1 10 0v4" />
    </svg>
  )
}
