import Link from "next/link"

export default function MLPredictorPage() {
  // In a real application, this data would come from an API call after audio submission
  const analyzedTranscript =
    "Patient presented with a persistent cough, mild fever, and general fatigue for the past three days. No significant medical history. Lung sounds are clear, but a slight wheezing is noted on deep inspiration."
  const predictedDisease = "Common Cold (Low Severity)"
  const confidenceScore = "85%"

  return (
    <div className="min-h-screen bg-background text-foreground">
      <header className="sticky top-0 z-40 w-full border-b border-border bg-background/80 backdrop-blur-sm">
        <div className="container flex h-16 items-center justify-between px-4 md:px-6">
          <Link href="/" className="text-2xl font-bold text-primary">
            vAIdya
          </Link>
          <nav className="hidden md:flex items-center space-x-6">
            <Link href="/ml-predictor" className="text-sm font-medium transition-colors hover:text-primary">
              ML Predictor
            </Link>
            <Link href="/doctors-notes" className="text-sm font-medium transition-colors hover:text-primary">
              Doctor&apos;s Notes
            </Link>
            <Link href="/our-progress" className="text-sm font-medium transition-colors hover:text-primary">
              Our Progress till Date
            </Link>
          </nav>
        </div>
      </header>
      <main className="flex flex-col items-center justify-center min-h-[calc(100vh-64px)] p-4 md:p-8">
        <h1 className="text-4xl md:text-5xl font-bold text-center text-balance mb-8">ML Predictor Analysis</h1>

        <div className="w-full max-w-3xl bg-card p-6 rounded-lg shadow-lg space-y-6">
          <div>
            <h2 className="text-2xl font-semibold text-primary mb-2">Analyzed Transcript</h2>
            <p className="text-muted-foreground leading-relaxed">{analyzedTranscript}</p>
          </div>
          <div className="border-t border-border pt-6">
            <h2 className="text-2xl font-semibold text-primary mb-2">Predicted Disease Classification</h2>
            <p className="text-xl font-bold text-foreground mb-2">{predictedDisease}</p>
            <p className="text-muted-foreground">
              Confidence Score: <span className="font-semibold text-primary">{confidenceScore}</span>
            </p>
          </div>
          <div className="border-t border-border pt-6">
            <Link
              href="/"
              className="inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 bg-secondary text-secondary-foreground hover:bg-secondary/80 h-10 px-4 py-2"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </main>
    </div>
  )
}
